#!/usr/bin/env python3
"""
Generate the coach's voice clips from lines.json -> voice/<id>.mp3

Run it from this folder on your own computer (needs Python 3 and an internet connection, no extra packages).

  ElevenLabs (default):
      export ELEVENLABS_API_KEY=your_key            # Windows PowerShell:  $env:ELEVENLABS_API_KEY="your_key"
      python generate_voice.py
      python generate_voice.py --voice <voice_id>    # any voice id from your ElevenLabs voice library

  OpenAI:
      export OPENAI_API_KEY=your_key
      python generate_voice.py --provider openai --voice onyx

Already generated clips are skipped, so you can re-run it safely. Use --force to regenerate everything.
Re-export lines.json from the site (Settings -> Export lines) whenever you add or change coach lines.
Never put your API key in index.html. Keep it on your own machine only.
"""
import argparse, json, os, sys, time, urllib.request, urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))

def eleven(text, voice, key, model):
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice}?output_format=mp3_44100_128"
    body = json.dumps({"text": text, "model_id": model,
                       "voice_settings": {"stability": 0.45, "similarity_boost": 0.75, "style": 0.25}}).encode()
    req = urllib.request.Request(url, data=body, headers={"xi-api-key": key, "Content-Type": "application/json", "Accept": "audio/mpeg"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read()

def openai(text, voice, key, model):
    body = json.dumps({"model": model, "voice": voice, "input": text, "response_format": "mp3",
                       "instructions": "Warm, upbeat, friendly chess coach. Natural pacing, encouraging, never robotic."}).encode()
    req = urllib.request.Request("https://api.openai.com/v1/audio/speech", data=body,
                                 headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--provider", choices=["elevenlabs", "openai"], default="elevenlabs")
    ap.add_argument("--voice", help="voice id (ElevenLabs) or voice name (OpenAI)")
    ap.add_argument("--model", help="override the TTS model")
    ap.add_argument("--lines", default=os.path.join(HERE, "lines.json"))
    ap.add_argument("--force", action="store_true", help="regenerate clips that already exist")
    a = ap.parse_args()

    if a.provider == "elevenlabs":
        key = os.environ.get("ELEVENLABS_API_KEY"); fn = eleven
        voice = a.voice or "JBFqnCBsd6RMkjVDRZzb"; model = a.model or "eleven_multilingual_v2"
    else:
        key = os.environ.get("OPENAI_API_KEY"); fn = openai
        voice = a.voice or "onyx"; model = a.model or "gpt-4o-mini-tts"
    if not key:
        sys.exit("Missing API key. Set ELEVENLABS_API_KEY or OPENAI_API_KEY (see the top of this file).")

    lines = json.load(open(a.lines, encoding="utf-8"))
    todo = [(i, t) for i, t in lines.items() if a.force or not os.path.exists(os.path.join(HERE, i + ".mp3"))]
    print(f"{len(lines)} lines, {len(todo)} to generate, {sum(len(t) for _, t in todo)} characters. Voice: {voice}")
    for n, (cid, text) in enumerate(todo, 1):
        for attempt in range(4):
            try:
                audio = fn(text, voice, key, model)
                open(os.path.join(HERE, cid + ".mp3"), "wb").write(audio)
                print(f"[{n}/{len(todo)}] {cid}.mp3")
                break
            except urllib.error.HTTPError as e:
                msg = e.read().decode("utf-8", "replace")[:200]
                if e.code in (429, 500, 502, 503) and attempt < 3:
                    time.sleep(2 * (attempt + 1)); continue
                sys.exit(f"HTTP {e.code} on {cid}: {msg}")
            except Exception as e:
                if attempt < 3: time.sleep(2); continue
                sys.exit(f"Failed on {cid}: {e}")
        time.sleep(0.15)
    print("Done. Put the voice/ folder next to index.html and reload the site.")

if __name__ == "__main__":
    main()
